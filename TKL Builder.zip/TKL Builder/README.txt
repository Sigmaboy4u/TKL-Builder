Requirements
To build the stub, you need:

Windows 10.
Python 3.10+.
An active internet connection.

How To Build

